=== Edubin Core ===
Contributors: Pixelcurve
Donate link: https://thepixelcurve.com
Tags: admin, customize, framework
Author: Pixelcurve
Author URI: https://thepixelcurve.com/
Tags: two-columns, three-columns, left-sidebar, sticky-post, theme-options, translation-ready.
Version: 8.13.22
Text Domain: edubin-core
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Plugin that adds additional features needed by our theme. It's also a framework to code your own widgets to help you make any kind of page. For more information about edubin please go to https://thepixelcurve.com/

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/Edubin-core` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Read our guide on how to Get Started with Edubin Core.


